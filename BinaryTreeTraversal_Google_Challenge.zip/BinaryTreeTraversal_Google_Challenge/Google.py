# -*- coding: utf-8 -*-
"""
Created on Mon Nov  9 00:11:22 2020

@author: Karthikeyan Gopinath
"""

import math



class treeNode():
    def __init__(self,node=None):
        self.node = node
        self.left = None
        self.right = None
        self._duplicateCount =0
        self._traverseValue=0

    def setDuplicateCount(self,duplicateCount):
        self._duplicateCount = duplicateCount
    def getLeftNode(self):
         return self.left
    def getRightNode(self):
        return self.right
    def __str__(self):
        return str(self.node)#+"\n" + str(self.left)+"\t"+str(self.right)
    
class binarySearchTree():
    def __init__(self):
        self._root = None
        self._height = 100000000
        self.__maxTreeHeight = 0
        self.__size=0
        self._travvalue=0
        
    def isEmpty(self):
        if self._root is None:
            return "Empty"
        else:
            return "Not Empty"
    
    def isFull(self):
        sizeCount = len(set(self._traverse(self._root)))+1
        if sizeCount >1001:
            return True
        else:
            return False
        
    def traverse(self):
        traverseList=self._traverse(self._root)
        return traverseList
            
    def _traverse(self,currNode):
        trav = list()     
        if currNode:
                        
            trav = self._traverse(currNode.left)
            #currNode._traverseValue=+1                   
            trav = trav + self._traverse(currNode.right)
            #currNode._traverseValue=+1             
            trav.append(currNode.node)
            
            
        return trav
 
   
    def _search(self,currentNode,Node):      
        if Node.node < currentNode.node and currentNode.left is not None:
            return self._search(currentNode.left,Node)          
        elif Node.node > currentNode.node and currentNode.right is not None:
            return self._search(currentNode.right,Node)           
        elif Node.node == currentNode.node:
            return currentNode
        elif currentNode.left is None and currentNode.right is None and Node.node != currentNode.node:
            return False
                  
    def search(self,val):
        Node = treeNode(val)
        if self.isEmpty()=='Empty':
            return False
        else:
            SearchVal= self._search(self._root,Node)          
            if SearchVal:
                return True
            else:
                return False
            
    # def searchTravValue(self,val):
    #     Node = treeNode(val)
    #     if self._root.node== val:
    #         return -1
    #     else:
    #         SearchVal= self._searchParentTraversalValue(self._root,Node,self._root)          
    #         return SearchVal
    
    def _maxHeight(self,Node):
        if Node is None:
            return 0
        else:
            leftMaxHeight = self._maxHeight(Node.left)
            rightMaxHeight = self._maxHeight(Node.right)
        
        if leftMaxHeight > rightMaxHeight:
            return leftMaxHeight+1
        else:
            return rightMaxHeight+1
 
    
    def insert(self,val):      
        Node=treeNode(val)
            
        if self.isEmpty()=='Empty':
            self._root = Node        
        else:
            self._insert(self._root,Node)
              
     #   print("Height: ",self.__maxTreeHeight,"\nSize: ",self.__size,"\n")
     #   self.rebal()

            
    def _insert(self,currentNode,Node):
   #     print(currentNode,Node)
        if Node.node < currentNode.node and currentNode.left is not None:
            self._insert(currentNode.left,Node)                  
        elif Node.node > currentNode.node and currentNode.right is not None:
            self._insert(currentNode.right,Node)
        elif currentNode.left is None and Node.node < currentNode.node:
            currentNode.left = Node
        elif currentNode.right is None and Node.node > currentNode.node:
            currentNode.right = Node
        elif Node.node == currentNode.node:             
             pass
    #    print("Node:",currentNode,"Left: ",currentNode.left,"Right: ",currentNode.right)

    def searchTravValueParent(self,val):
        Node = treeNode(val)
        SearchVal= self._searchTraversalValueParent(self._root,Node,self._root)          
        return SearchVal
                           
    def _searchTraversalValueParent(self,currentNode,Node,parentNode):      
        if Node.node < currentNode.node and currentNode.left is not None:           
            return self._searchTraversalValueParent(currentNode.left,Node,currentNode)          
        elif Node.node > currentNode.node and currentNode.right is not None:
            return self._searchTraversalValueParent(currentNode.right,Node,currentNode)           
        elif Node.node == currentNode.node:
            if currentNode._traverseValue == self._travvalue:
                return -1
            else:
                return parentNode._traverseValue        
        elif currentNode.left is None and currentNode.right is None and Node.node != currentNode.node:
            return False  


    def setTravValue(self,val):
        Node = treeNode(val)
        SearchVal= self._setTraverseValue(self._root,Node,self._root)          
        return SearchVal

    def _setTraverseValue(self,currentNode,Node,parentNode):      
        if Node.node < currentNode.node and currentNode.left is not None:
            return self._setTraverseValue(currentNode.left,Node,currentNode)          
        elif Node.node > currentNode.node and currentNode.right is not None:
            return self._setTraverseValue(currentNode.right,Node,currentNode)           
        elif Node.node == currentNode.node:
            currentNode._traverseValue=self._travvalue+1
            self._travvalue +=1
        elif currentNode.left is None and currentNode.right is None and Node.node != currentNode.node:
            return False                       
 
    def traverseValue(self):
        traverseList=self._traverseValue(self._root)
        return traverseList
            
    def _traverseValue(self,currNode):
        trav = list()     
        if currNode:             
            trav = self._traverseValue(currNode.left)            
            trav = trav + self._traverseValue(currNode.right)
            trav.append(currNode._traverseValue)
        #print(trav)
        return trav




def nodeArranger(l,NodGenAtEachLevel,NodePosition,FinalNode,height):
    i=0
    NodeInc=NodePosition
    if NodGenAtEachLevel==1:
        FinalNode.append( l[int(NodePosition)-1])   
    
    if NodePosition !=1 and NodGenAtEachLevel!=1:
        while i<NodGenAtEachLevel:
           #  print("node at each level",NodGenAtEachLevel,"Node Position:",NodePosition,"incremental",i)
    
             if l[int(NodePosition)-1] not in FinalNode:  
                  FinalNode.append( l[int(NodePosition)-1])
           # print(FinalNode)
           # print(l[int(NodePosition)])
             NodePosition += NodeInc
             i+=1
           
    elif NodePosition==1:
        templist= [i for i in l if i not in FinalNode]
        FinalNode= FinalNode+templist
    return FinalNode

def solution(h,q):
    h=h
    nodes=q
    
    if h==0:
        return [-1]
    elif h==1:
        returnList=list()
        for i in nodes:
            if i==3:
                returnList.append(-1)
            elif i==2:
                returnList.append(3)
            elif i==1:
                returnList.append(3)
        
        return returnList
    elif h>1:
    
        height= int(math.pow(2,h))
        l=[x for x in range(height)]
        l.pop(0)
        l.sort()
        
        NodGenAtEachLevel = [int(math.pow(2,x)) for x in range(h)]
        for i in range(len(NodGenAtEachLevel)):
            if i !=0:
                NodGenAtEachLevel[i]+=NodGenAtEachLevel[i-1]
            else:
                NodGenAtEachLevel=NodGenAtEachLevel
    
        Node_needed_each_level=[]
        NodePosition= int(math.pow(2,h))/2
        FinalNode= list() #[l[int(math.pow(2,h)/2)-1]]
        for k in range(h):
          #NodePosition= int(NodePosition/2)
          FinalNode =  nodeArranger(l,NodGenAtEachLevel[k],NodePosition,FinalNode,height)
         # print("Back to main")
          NodePosition= int(NodePosition/2)
        #  print(NodePosition)
        #print(FinalNode)
#    print(FinalNode)   
    BinaryTree = binarySearchTree()  
    
    for i in range(len(FinalNode)):
        BinaryTree.insert(FinalNode[i])
      
        
    Posttravlis= BinaryTree.traverse()
    
    for i in range(len(Posttravlis)):
        BinaryTree.setTravValue(Posttravlis[i])
    # BinaryTree.insert(4)
    # BinaryTree.insert(2)
    # BinaryTree.insert(6)
    # BinaryTree.insert(1)
    # BinaryTree.insert(3)
    # BinaryTree.insert(5)
    # BinaryTree.insert(7)
    # print("All inserted")

     
    # BinaryTree.setTravValue(1)
    # BinaryTree.setTravValue(3)
    # BinaryTree.setTravValue(2)
    # BinaryTree.setTravValue(5)
    # BinaryTree.setTravValue(7)
    # BinaryTree.setTravValue(6)
    # BinaryTree.setTravValue(4)
    
  #  Cmopare the belwo 2 result
    PostTravValue= BinaryTree.traverseValue()
    
 #   print("Tree value")
#    BinaryTree.traverse()
    FinalResult=list()
    
    
    for i in range(len(nodes)):
        if nodes[i] in PostTravValue:
            index = PostTravValue.index(nodes[i])
            FinalResult.append(BinaryTree.searchTravValueParent(Posttravlis[index]))
        else:
            FinalResult.append('')
    #print(BinaryTree.searchTravValueParent(7))
    
    return FinalResult
  #  print(BinaryTree.searchTravValueParent(4))
    
    
    
        
s=solution(5,[100,6])
print(s)