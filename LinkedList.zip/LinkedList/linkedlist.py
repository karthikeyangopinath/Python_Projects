# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 19:35:10 2020

@author: Karthikeyan Gopinath
"""

#Creation of the ListNode class with its attributes
class ListNode:
    def __init__(self,cargo=None,next=None):
        self._cargo=cargo
        self._next=next
        
    def __str__(self):
        return str(self._cargo)

#Creation of the LinkedList class with its attributes
class LinkedList:
    def __init__(self):
        self.__first_node =None
        self.__size=0
        
    def is_empty(self):
        if self.__first_node is None:
            return "Empty"
        else:
            return "Not Empty"   
        
    def is_full(self):
        sizeCount = len(self.__traverse(self.__first_node))
       # print(sizeCount)
        if sizeCount >=1001:
            return True
        else:
            return False
        
    def insert(self,val):
        node = ListNode(val)

        if self.is_full():
            print("The tree is full. Cannot insert")
            return
        elif self.is_empty() == 'Empty':
            self.__first_node=node
            self.__size=1
        else:
            self.__insert(self.__first_node,node)
    
    def __insert(self,current_node,node):
        if current_node and current_node._next is not None:
            self.__insert(current_node._next,node)
        else:
            current_node._next=node
            self.__size+=1
    
    def search(self,val):      
        if self.__first_node is None:
            return False
        else:
            SearchResult=self.__search(self.__first_node,val)
            if SearchResult:
                return True
            else:
                return False
    def __search(self,current_node,val):
        if current_node._next and current_node._cargo != val:
            return self.__search(current_node._next,val)
        elif current_node._cargo == val:
            return current_node
        else: 
            return False
    
    def delete(self,val):
        if self.__first_node is None:
            print( "Empty List. Please insert Nodes first")
        elif self.__first_node._cargo == val:
            self.__first_node = self.__first_node._next
        elif self.__search(self.__first_node,val):
            self.__delete(self.__first_node,val)
        else:
            print("The Node is not present in the list")
    
    def __delete(self,current_node,val):
        if current_node and current_node._next._cargo != val:
            self.__delete(current_node._next,val)
        elif current_node and current_node._next._cargo == val:
            current_node._next = current_node._next._next
        else:
            current_node =None
            
    def traverse(self):
        traverseList=self.__traverse(self.__first_node)
        print(traverseList)
            
    def __traverse(self,current_node):
        trav=[]
        while current_node:
            trav.append(current_node._cargo)
            current_node=current_node._next                                      
        return trav
              
    def __str__(self):
        return str("Root:")+str(self.__first_node) + str("\n")+str("size:")+str(self.__size)
  

""" 
Some Key commands to be used for Linked List

Instantiating
l=LinkedList()

insert(Enter integer value) - Inserts a value into the linked list.
Eaxmple:    l.insert(val)

search(Enter integer value) - Returns a binary value of the search value
Eaxmple:    print(l.search(val))

delete(Enter integer value) - Deletes the 1st occurance of the value from the Linked List
Eaxmple:    l.delete(val)

traverse() - Returns the values from the linked list in the order in whihc they were inserted
Example:    l.traverse() 

print(List_obj) - will print the first_node and the List

is_full() - Returns a message when tree is full
Example: l.is_full()

is_empty() - Retuns a message to check if the tree is empty or full

"""