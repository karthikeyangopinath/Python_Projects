# -*- coding: utf-8 -*-

"""
Created on Fri Nov  6 12:40:03 2020

@author: Karthikeyan Gopinath
"""

import math
#Creating the Tree Node Class and its attributes.
# The duplicate count is added to allow duplicate values to be inserted into
# Height of the node in the tree is also set here
class treeNode():
    def __init__(self,node=None):
        self.node = node
        self.left = None
        self.right = None
        self._duplicateCount =0
        self._height=0

    def setHeight(self,height):
        self._height= height
    def setDuplicateCount(self,duplicateCount):
        self._duplicateCount = duplicateCount
    def getDuplicateCount(self):
        return self._duplicateCount
    def getLeftNode(self):
         return self.left
    def getRightNode(self):
        return self.right
    def getHeight(self):
        return self._height
    def __str__(self):
        return str(self.node)
    
class binarySearchTree:
    def __init__(self):
        self.__root = None
        self.__height = 10
        self.__maxTreeHeight = 0
        self.__size=0
        
    def isEmpty(self):
        if self.__root is None:
            return "Empty"
        else:
            return "Not Empty"
    
    def isFull(self):
        sizeCount = len(set(self.__traverse(self.__root)))+1
        if sizeCount >1001:
            return True
        else:
            return False
        
    def traverse(self):
        traverseList=self.__traverse(self.__root)
        print(traverseList)
            
    def __traverse(self,currNode):
        trav = list()     
        if currNode:             
            trav = self.__traverse(currNode.left)            
            trav.append(currNode.node)
            if currNode and len(trav)>0 and  currNode._duplicateCount > 0:
                for i in range(currNode._duplicateCount):
                    trav.append(currNode.node)
            trav = trav + self.__traverse(currNode.right)
        return trav
    
    #The below functions are used for re-balancing the tree incase if found it is unbalanced
    # This is called by the rebal() function down to get the duplicate count of the nodes
    def __traverseNoDuplicates(self,currNode):
        trav = list()     
        if currNode:             
            trav = self.__traverseNoDuplicates(currNode.left)            
            trav.append(currNode.node)
            trav = trav + self.__traverseNoDuplicates(currNode.right)
        return trav
    
    #The below functions are used for re-balancing the tree incase if found it is unbalanced
    # this is called by the rebal() function down to get the duplicate count of the nodes
    def __traverseDuplicateCount(self,currNode):
        #print(currNode)
        trav = list()     
        if currNode:             
            trav = self.__traverseDuplicateCount(currNode.left)            
            trav.append(currNode._duplicateCount)
            trav = trav + self.__traverseDuplicateCount(currNode.right)
       # print(trav)
        return trav
    
    
    def __search(self,currentNode,Node):      
        if Node.node < currentNode.node and currentNode.left is not None:
            return self.__search(currentNode.left,Node)          
        elif Node.node > currentNode.node and currentNode.right is not None:
            return self.__search(currentNode.right,Node)           
        elif Node.node == currentNode.node:
            return currentNode
        elif currentNode.left is None and currentNode.right is None and Node.node != currentNode.node:
            return False
                  
    def search(self,val):
        Node = treeNode(val)
        if self.isEmpty()=='Empty':
            return False
        else:
            SearchVal= self.__search(self.__root,Node)          
            if SearchVal:
                return True
            else:
                return False
    
    def __maxHeight(self,Node):
        if Node is None:
            return 0
        else:
            leftMaxHeight = self.__maxHeight(Node.left)
            rightMaxHeight = self.__maxHeight(Node.right)
        
        if leftMaxHeight > rightMaxHeight:
            return leftMaxHeight+1
        else:
            return rightMaxHeight+1
    
    def __rebal(self,val,duplicateCount):      
        Node=treeNode(val)
        Node.setDuplicateCount(duplicateCount)
        if self.isEmpty()=='Empty':
            self.__root = Node        
        else:
            self.__rebalinsert(self.__root,Node)        
    def __rebalinsert(self,currentNode,Node):
        if Node.node < currentNode.node and currentNode.left is not None:
            self.__rebalinsert(currentNode.left,Node)
                            
        elif Node.node > currentNode.node and currentNode.right is not None:
            self.__rebalinsert(currentNode.right,Node)
            
        elif currentNode.left is None and Node.node < currentNode.node:
            currentNode.left = Node
            
        elif currentNode.right is None and Node.node > currentNode.node:
            currentNode.right = Node
            
        elif Node.node == currentNode.node:
             currentNode._duplicateCount=Node._duplicateCount
             pass   
    
    def insert(self,val):      
        Node=treeNode(val)
        
        if self.isFull():
            print("Tree is full. Cannot Insert")
            return
                 
        if self.isEmpty()=='Empty':
            self.__root = Node        
        else:
            self.__insert(self.__root,Node)
        

        #Setting some key atrbiutes to the Tree
        self.__maxTreeHeight = self.__maxHeight(self.__root)
        self.__size = len(set(self.__traverse(self.__root)))
        
     #   print("Height: ",self.__maxTreeHeight,"\nSize: ",self.__size,"\n")
        self.rebal()

    def rebal(self):        
        #Checking if the tree is balanced or not else we are re-balancing the tree to give optimal efficency
        # Balancing Formula Used Here:  Check the OPtimal tree hight for the size of the tree
        #b. If the current size of the tree is found to be greater than than optimal size of the tree
        #c. Then we get the list of values in the List and sort it. Duplicate values will taken in separate list and later will be added as an attribute while building the Optimal Tree
        #d. Then we get 'Median' of the values to find the OPtimal Parent NOde of the tree
        #e. Then for the left child node of the parent we get n-2 Position of the values in the list
        #f. For the right child of the Parent Node we get the n+2 Position of the values in the list
        #g. We repeat the steps for the subsequent child sub-parent nodes by taking (n-2)th postion for left and (n+2)th position
        #h. The remaining values which arent added , are later appeneded to the list
        #i. the Final list is then ready for Binary Tree Insertion
        #g. Later the rebalanced Tree is replaces the current Tree
        
        #Reason for taking n-2 and N+2 positions of the list is because in binary tree, we have centre node with 1 value less and 1 value more to be more balanced. for example in a list [1,2,3]
        #The tree will be more balanced if we take 2 as the parent node , rather than taken higest value 3 or the lowest value 1 , since the hightest and lowest values will result in a unbalanced tree
        #An unbalanced tree has more impacts on the performance of the Search functionality
        if self.__size >1 and  math.pow(2,self.__maxTreeHeight-1) > self.__size:
        #    print("Height: ",self.__maxTreeHeight,"\nSize: ",self.__size,"\n")
       #     print("inside Rebal")
            nodeList= self.__traverseNoDuplicates(self.__root)         
            nodeDuplicateCountList= self.__traverseDuplicateCount(self.__root)
            nodeDuplicateCount=dict(zip(nodeList,nodeDuplicateCountList))
            
            if nodeList:
                      
                    nodeList.sort() 
                    nodeListLen = len(nodeList)
                    
                    if nodeListLen%2 == 0:
                        subTreePNodePos = int((nodeListLen)/2)+1
                    else:
                        subTreePNodePos = int((nodeListLen)/2)
               
                    subTreePNode = nodeList[subTreePNodePos-1]
                    
                   
                    subTreeLeftInsertion =  nodeList[0:int(subTreePNodePos)-1]
                    subTreeRightInsertion = nodeList[int(subTreePNodePos):]
                   
                    subTreeLeftInsertion.sort(reverse=True)
                    subTreeRightInsertion.sort()
                    
                    #Building the Binary SearchTree              
                    subTree = binarySearchTree()
                    subTree.__rebal(subTreePNode,nodeDuplicateCountList[subTreePNodePos-1])
                    
                    
                    #print("Sub Tree P Node:", subTree)
                    subTreeOrder=list()
                    j=1
                    while j<=int(len(subTreeLeftInsertion)/2):                
                        subTreeOrder.append(subTreeLeftInsertion[j])
                        subTreeLeftInsertion.remove(subTreeLeftInsertion[j])
                        j+=2
                    else:
                        subTreeOrder=subTreeOrder+subTreeLeftInsertion
                    j=1
                    while j<=int(len(subTreeRightInsertion)/2):                
                        subTreeOrder.append(subTreeRightInsertion[j])
                        subTreeRightInsertion.remove(subTreeRightInsertion[j])
                        j+=2
                    else:
                        subTreeOrder=subTreeOrder+subTreeRightInsertion
                   
                    
                    for i in range(len(subTreeOrder)):
                        subTree.__rebal(subTreeOrder[i],nodeDuplicateCount[subTreeOrder[i]])
                    #subTree.traverse()   
   #***************************Updating the tree with balanced Tree *************
                    self is None
                    
                    self.__root = subTree.__root

            
    def __insert(self,currentNode,Node):
        if Node.node < currentNode.node and currentNode.left is not None:
            self.__insert(currentNode.left,Node)                  
        elif Node.node > currentNode.node and currentNode.right is not None:
            self.__insert(currentNode.right,Node)
        elif currentNode.left is None and Node.node < currentNode.node:
            currentNode.left = Node
        elif currentNode.right is None and Node.node > currentNode.node:
            currentNode.right = Node
        elif Node.node == currentNode.node:
             currentNode._duplicateCount+=1
             pass



    def delete(self,val):
        Node=treeNode(val)
        nodeFound=""
        # Check if the Tree is empty and return null if empty
        if self.isEmpty()=='Empty':
            print("Tree is empty")
        else:
        #Search for the Node in the tree and check if Node is present or not    
            nodeFound = self.__search(self.__root,Node)                            
        #If node is not present then return the node is not present    
            if not nodeFound:
               print("The value is not present in the Binary Tree")
         # If node is present then next step to traverse and get the list of nodes for which re-order is needed
         #Get the nodes to be re-strcuted ina list called Node list
         #Create a Binary tree with the first node and call it sub-tree
         # Check the position of the Node to be deleted and then re-point its parent node to the sub-tree
            
            elif nodeFound:
               DelNodeReStruct=nodeFound
               
              # print("Delete Node details",Node)
               nodeList= self.__traverseNoDuplicates(DelNodeReStruct)
               nodeDuplicateCountList= self.__traverseDuplicateCount(DelNodeReStruct)
               nodeDuplicateCount=dict(zip(nodeList,nodeDuplicateCountList))
               nodeList=[i for i in nodeList if i!=Node.node] 
               # Inorder to re-insert the values into the tree. It is very essential to find the correct fit of the remaining
               # nodes , else the Binary tree might be unbalanced and the search times will be longer.
               #However this comes with the cost. Since balancing means finding the rigth fit and then re-arranging the tree
               # Here in this scenario , the best fit that Im taking into consideration is the Median value of the Nodes
               # So am going to take the median of the nodes that are going to be re-inserted and then find the correct node with which we can built a sub tree and append it to the main Binary tree
               
               if nodeList:
                   
                   nodeList.sort() 
                   nodeListLen = len(nodeList)
                                     
                   if nodeListLen%2 == 0:
                       subTreePNodePos = int((nodeListLen)/2)+1
                   else:
                       subTreePNodePos = int((nodeListLen)/2)
               
                   subTreePNode = nodeList[subTreePNodePos-1]                                     
                   subTreeLeftInsertion =  nodeList[0:int(subTreePNodePos)-1]
                   subTreeRightInsertion = nodeList[int(subTreePNodePos):]
                   
                   subTreeLeftInsertion.sort(reverse=True)
                   subTreeRightInsertion.sort()
                   
                   #Building the Binary SearchTree              
                   subTree = binarySearchTree()
                   subTree.__rebal(subTreePNode,nodeDuplicateCountList[subTreePNodePos-1])
                                     
                   #print("Sub Tree P Node:", subTree)
                   subTreeOrder=list()
                   j=1
                   while j<=int(len(subTreeLeftInsertion)/2):                
                       subTreeOrder.append(subTreeLeftInsertion[j])
                       subTreeLeftInsertion.remove(subTreeLeftInsertion[j])
                       j+=2
                   else:
                       subTreeOrder=subTreeOrder+subTreeLeftInsertion
                   j=1
                   while j<=int(len(subTreeRightInsertion)/2):                
                       subTreeOrder.append(subTreeRightInsertion[j])
                       subTreeRightInsertion.remove(subTreeRightInsertion[j])
                       j+=2
                   else:
                       subTreeOrder=subTreeOrder+subTreeRightInsertion
                   
                   #print(subTreeOrder)
                   for i in range(len(subTreeOrder)):
                       subTree.__rebal(subTreeOrder[i],nodeDuplicateCount[subTreeOrder[i]])

                   
                   searchParent=self.__searchParentSearch(self.__root,Node,self.__root)
                   
                   if self.__root.node == DelNodeReStruct.node and self.__root._duplicateCount==0:
                       self.__root is None
                       self.__root = subTree.__root
                   elif self.__root.node == DelNodeReStruct.node and self.__root._duplicateCount>0:
                       self._root.duplicateCount-=1
                   elif searchParent.left:
                       if searchParent.left.node == DelNodeReStruct.node and searchParent.left._duplicateCount==0:
                           searchParent.left = None
                           searchParent.left = subTree.__root
                       elif searchParent.left.node == DelNodeReStruct.node and searchParent.left._duplicateCount>0:
                          searchParent.left._duplicateCount-=1
                   if searchParent.right:
                       if searchParent.right.node == DelNodeReStruct.node and searchParent.right._duplicateCount==0:
                           searchParent.right = None
                           searchParent.right = subTree.__root
                       elif searchParent.right.node == DelNodeReStruct.node and searchParent.right._duplicateCount>0:
                          searchParent.right._duplicateCount-=1
                         
               else:
                   
                   searchParent=self.__searchParentSearch(self.__root,Node,self.__root)
                   
                   if searchParent.left:
                       if searchParent.left.node == Node.node and searchParent.left._duplicateCount==0:
                           searchParent.left=None
                       elif searchParent.left.node == Node.node and searchParent.left._duplicateCount>0:                           
                           searchParent.left._duplicateCount-=1

                    
                   if searchParent.right:
                       if searchParent.right.node == Node.node and searchParent.right._duplicateCount==0:
                        searchParent.right=None
                       elif searchParent.right.node == Node.node and searchParent.right._duplicateCount>0:
                           searchParent.right._duplicateCount-=1
                           
                        

    
    def __searchParentSearch(self,currentNode,Node,parentNode):      
        if Node.node < currentNode.node and currentNode.left is not None:
            return self.__searchParentSearch(currentNode.left,Node,currentNode)          
        elif Node.node > currentNode.node and currentNode.right is not None:
            return self.__searchParentSearch(currentNode.right,Node,currentNode)           
        elif Node.node == currentNode.node:
            return parentNode
        elif currentNode.left is None and currentNode.right is None and Node.node != currentNode.node:
            return False                   
  
    
    def __str__(self):
        return str(self.__root.node)



""" 
Some Key commands to be used for Linked List

Instantiating
bst=binarySearchTree()

insert(Enter integer value) - Inserts a value into the bst.
Eaxmple:    bst.insert(val)

search(Enter integer value) - Returns a binary value of the search value
Eaxmple:    print(bst.search(val))

delete(Enter integer value) - Deletes the 1st occurance of the value from the bst
Eaxmple:    bst.delete(val)

traverse() - Returns the values from the bst in ascending order
Example:    bst.traverse() 

print(tree_obj) - will print the root_node and the treesize

isFull() - Returns a message when tree is full
Example: print(bst.isFull())

isEmpty() - Retuns a message to check if the tree is empty or full

"""