# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 10:14:39 2020

@author: Karthikeyan Gopinath
"""
import json
import datetime

class Product:
    def __init__(self,name,price,EAN,brand,quantity=0):
        self._name=name
        self._price=price
        self._quantity=quantity
        self._EAN=EAN
        self._brand=brand
        
    def getName(self):
        return self._name
    def getPrice(self):
        return self._price
    def getQuantity(self):
        return self._quantity
    def getBrand(self):
        return self._brand
    def getEAN(self):
        return self._EAN
    def setName(self,name):
        self._name =name
    def setPrice(self,price):
        self._price=price
    def setQuantity(self,quantity):
        self._quantity=quantity
    
    def __str__(self):
        return "Name:\t"+self._name+"\n"+"Price: \t"+str(self._price)+"\n"+"Quantity: \t"+str(self._quantity)+"\n"+"EAN: \t"+str(self._EAN)

class Clothing(Product):
    def __init__(self,pType="Clothing",name="",price=0,EAN="",brand="",quantity=0,size="",material=""):
        super().__init__(name,price,EAN,brand,quantity)
        self._pType=pType
        self._size=size
        self._material=material
    def getProductType(self):
        return self._pType
    def getSize(self):
        return self._size
    def getMaterial(self):
        return self._material
    def __str__(self):
        return "Name:\t"+self._name+"\n"


class Food(Product):
    def __init__(self,pType="Food",name="",price=0,EAN="",brand="",quantity=0,expiryDate="2021-09-09",glutenFree="",suitableForVegans="N"):
        super().__init__(name,price,EAN,brand,quantity)
        self._pType = pType
        self._expiryDate=expiryDate
        self._glutenFree=glutenFree
        self._suitableForVegans=suitableForVegans
    
    def getProductType(self):
        return self._pType
    def getExpiryDate(self):
        return self._expiryDate
    def getGlutenFree(self):
        return self._glutenFree
    def getSuitableForVeg(self):
        return self._suitableForVegans
    def __str__(self):
        return "Name:\t"+self._name+"\n"+"Price: \t"+str(self._price)+"\n"+"Quantity: \t"+str(self._quantity)+"\n"+"Expiry Date: \t"+str(self._expiryDate)+"\n"+"Gluten Free: \t"+str(self._glutenFree)+"\n"+"Suitable for Vegans: \t"+str(self._suitableForVegans)+"\n"+"EAN: \t"+str(self._EAN)

class Beverages(Product):
    def __init__(self,pType="Food",name="",price=0,EAN="",brand="",quantity=0,bType="",blevel="",suitableTemp="0"):
        super().__init__(name,price,EAN,brand,quantity)        
        self._pType = pType
        self._bType = bType
        self._suitableTemp =suitableTemp
    def getProductType(self):
        return self._pType
    def getBType(self):
        return self._bType
    def getSuitableTemp(self):
        return self._suitableTemp

class ShoppingCart:
    def __init__(self):
        self._cart=list()
#We have used the List of dictionaries so that it will be easy to convert to JSON and maintain multiple Products with different types.
#A list of classes would be sufficient but i have used list of dictionaery for the convinience
# We check for each PRoduct Type and then add it to the cart
    def addProduct(self,p): 
        
        if p.getProductType() == 'Clothing':
            d={"Type":p.getProductType(),"Name":p.getName(),"Brand":p.getBrand() ,"Price":p.getPrice(), "Quantity":p.getQuantity() ,"Size":p.getSize() ,"Material":p.getMaterial() ,"EAN":p.getEAN()}  
        
            if not self._cart:
                self._cart.append(d)

            else:
                appendCounter=0
                cartCount=len(self._cart)
                for i in range(cartCount):
                    d1= self._cart[i]
                    tempdict={}
                    
                    if d["Type"]==d1["Type"] and d["Name"]==d1["Name"] and d["Brand"]==d1["Brand"] and d["Price"]==d1["Price"] and d["EAN"]==d1["EAN"] and d["Size"] == d1["Size"] and d["Material"]== d1["Material"]:
                        d1["Quantity"] = int(d["Quantity"])+ int(d1["Quantity"])
                        tempdict={"Type":"Clothing","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"Size":d1["Size"],"Material":d1["Material"],"EAN":d1["EAN"]}
                        
                        self._cart.pop(i)                                        
                        self._cart.append(tempdict)                    
                        appendCounter = appendCounter+1
                        break
                if appendCounter==0:
                    self._cart.append(d)
                            

        
        elif p.getProductType() == 'Food':
            
            d={"Type":p.getProductType(),"Name":p.getName(),"Brand":p.getBrand() ,"Price":p.getPrice(), "Quantity":p.getQuantity() ,"ExpiryDate":p.getExpiryDate() ,"GlutenFree":p.getGlutenFree() ,"SuitableforVegan":p.getSuitableForVeg(),"EAN":p.getEAN()}  

            if not self._cart:
                
                self._cart.append(d)
            else:
                appendCounter=0
                for i in range(len(self._cart)):
                    d1= self._cart[i]
                    tempdict={}
                    
                    if d["Type"]==d1["Type"] and d["Name"]==d1["Name"] and d["Brand"]==d1["Brand"] and d["Price"]==d1["Price"] and d["EAN"]==d1["EAN"] :
                        d1["Quantity"] = int(d["Quantity"])+ int(d1["Quantity"])
                        tempdict={"Type":"Food","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"ExpiryDate":d1["ExpiryDate"],"GlutenFree":d1["GlutenFree"],"SuitableforVegan":d1["SuitableforVegan"],"EAN":d1["EAN"]}
                        self._cart.pop(i)                    
                        self._cart.append(tempdict)
                        appendCounter = appendCounter+1
                        break
                if appendCounter==0:
                    self._cart.append(d)
        
        elif p.getProductType() == 'Beverages':
            d={"Type":p.getProductType(),"Name":p.getName(),"Brand":p.getBrand() ,"Price":p.getPrice(), "Quantity":p.getQuantity() ,"BType":p.getBType(),"SuitableTemp":p.getSuitableTemp() ,"EAN":p.getEAN()}  
        
            if not self._cart:
                self._cart.append(d)

            else:
                appendCounter=0
                cartCount=len(self._cart)
                for i in range(cartCount):
                    d1= self._cart[i]
                    tempdict={}
                    
                    if d["Type"]==d1["Type"] and d["Name"]==d1["Name"] and d["Brand"]==d1["Brand"] and d["Price"]==d1["Price"] and d["EAN"]==d1["EAN"] :
                        d1["Quantity"] = int(d["Quantity"])+ int(d1["Quantity"])
                        tempdict={"Type":"Beverages","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"BType":d1["BType"],"SuitableTemp":d1["SuitableTemp"],"EAN":d1["EAN"]}
                        
                        self._cart.pop(i)                                        
                        self._cart.append(tempdict)                    
                        appendCounter = appendCounter+1
                        break
                if appendCounter==0:
                    self._cart.append(d)
                            
        
        
        return self._cart
    
    def removeProduct(self,p):
        #Step1 : Loading the Products to be removed into a tempList
        #Step2: Check the count of Product to be removed from the list and take necessary action
        #           a. If TempList is null means the user has given invalid input
        #           b. If Templist ==1 there is one product to remove
        #           c. If TempList >1 there are more than 1 products to remove and we take further steps to remove the PRoducts
        remProdName = p
        cartCount=len(self._cart)
        tempdict={}
        tempRemList=list()
        for i in range(cartCount):
            d1= self._cart[i]
            if d1["Name"] == remProdName and d1["Type"]=='Clothing':
                tempdict={"Type":"Clothing","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"Size":d1["Size"],"Material":d1["Material"],"EAN":d1["EAN"]}
                tempRemList.append(tempdict)
            elif d1["Name"] == remProdName and d1["Type"]=='Food':
                tempdict={"Type":"Food","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"ExpiryDate":d1["ExpiryDate"],"GlutenFree":d1["GlutenFree"],"SuitableforVegan":d1["SuitableforVegan"],"EAN":d1["EAN"]}
                tempRemList.append(tempdict)
            elif d1["Name"] == remProdName and d1["Type"]=='Beverages':
                tempdict={"Type":"Beverages","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"BType":d1["BType"],"SuitableTemp":d1["SuitableTemp"],"EAN":d1["EAN"]}
                tempRemList.append(tempdict)
        
        # There are no Products to Remove
        if not tempRemList:
                print("******No product weas removed from the cart.Please try again with correct Product Name*****")
                return self._cart
        
        # Has just 1 product to remove
        elif len(tempRemList) == 1:
            cartCount=len(self._cart)
            tempdict={}
            for i in range(cartCount):
                d1= self._cart[i]
                tempdict= tempRemList[0]
                if d1["Name"] == tempdict["Name"] and d1["Type"]=='Clothing':
                    self._cart.pop(i)
                    print("The Product",remProdName, " has been removed from the cart")
                    return self._cart
                    break
                elif d1["Name"] == tempdict["Name"] and d1["Type"]=='Food':
                    self._cart.pop(i)
                    print("The Product",remProdName, " has been removed from the cart")
                    return self._cart
                    break
                elif d1["Name"] == tempdict["Name"] and d1["Type"]=='Beverages':
                    self._cart.pop(i)
                    print("The Product",remProdName, " has been removed from the cart")
                    return self._cart
                    break
        
        # Has more than 1 Products to Remove        
        elif len(tempRemList)>1:

            cartCount=len(tempRemList)
            tempdict={}
            
            print("Clothing Products \n")
            print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format("Sno","Type","EAN","Name","Brand","Price","Quantity","Size","Material"))
            for i in range(cartCount):
                d1= tempRemList[i]
                if d1["Type"]=='Clothing':
                    print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format(i,d1["Type"],str(d1["EAN"]),d1["Name"],d1["Brand"],str(d1["Price"]),str(d1["Quantity"]),d1["Size"],d1["Material"]))
            
            print("\n\n")
            print("______________________________________________________________________________________________________________________________________________________________")
            print("Food Products \n")
            print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format("Sno","Type","EAN","Name","Brand","Price","Quantity","ExpiryDate","GlutenFree","SuitableforVegan"))
            for i in range(cartCount):
                d1=tempRemList[i]
                if d1["Type"]=='Food':
                    print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format(i,d1["Type"],str(d1["EAN"]),d1["Name"],d1["Brand"],str(d1["Price"]),str(d1["Quantity"]),d1["ExpiryDate"],d1["GlutenFree"],d1["SuitableforVegan"]))
            print("______________________________________________________________________________________________________________________________________________________________")
            print("Beverages \n")
            print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format("Sno","Type","EAN","Name","Brand","Price","Quantity","BType","SuitableTemp"))
            for i in range(cartCount):
                d1= tempRemList[i]
                if d1["Type"]=='Beverages':
                    print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format(i,d1["Type"],str(d1["EAN"]),d1["Name"],d1["Brand"],str(d1["Price"]),str(d1["Quantity"]),d1["BType"],d1["SuitableTemp"]))
            
            print("\n\n")
            
            
            print("There are "+str(len(tempRemList))+ "  products to remove. Please enter the Serial Number of which Product you should Remove: ")            
            print("Please enter the Product Type and EAN to Remove")
            remProdType = input("Product Type: ")
            if remProdType.upper()=='C':
                print("**************The Current Operation is cancelled***********")
                return self._cart
            remProdEAN = input("EAN: ")
            if str(remProdEAN).upper()=='C':
                print("**************The Current Operation is cancelled***********")
                return self._cart
            
            inpValidation=0
            cartCount=len(self._cart)
            
            for i in range(cartCount):
                try:
                    d1=self._cart[i]
                except IndexError:
                    pass
                
                if d1["Type"].upper()==remProdType.upper() and d1["EAN"]==remProdEAN:
                    try:
                        self._cart.pop(i)
                    except IndexError:
                        pass
                    inpValidation+=1
                        
            if inpValidation==0:
                print("Invalid Inputs Please try again with the correct options")
            
            
            return self._cart
        
 # This method displays the summary of the cart in a formatted way
# Here we use the format method to format different outputs to the user so that it is readable
# Also, total for each Product and Overall total is calculated in this method   
    def showSummary(self):
        cartCount=len(self._cart)
        total = 0
          
        print("Summary of the Shopping:")
        print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format("Sno","Type","EAN","Name","Brand","Price (in £)","Quantity","Total(in £)"))
        for i in range(cartCount):
            d1= self._cart[i]
            total += round(float(d1["Quantity"])*float(d1["Price"]),2)
            d1["Total"]=round(float(d1["Quantity"])*float(d1["Price"]),2)
           
            print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format(str(i+1),d1["Type"],str(d1["EAN"]),d1["Name"],d1["Brand"],str(d1["Price"]),str(d1["Quantity"]),str(float(d1["Price"])*float(d1["Quantity"]))))
            
        print("_________________________________________________________________________________________________________________________")
        print("{:<3}{:<15}{:<20}{:<20}{:<20}{:<20}{:<20}{:<20}".format("  ","  ","  ","  ","  ","  ","Overall Total(in £): ",str(total)))
         
         
    def changeProductQuantity(self,p,q):
        #Step1 : Loading the Products to be Changed into a tempList
        #Step2: Check the count of Product to be Changed from the list and take necessary action
        #           a. If TempList is null means the user has given invalid input
        #           b. If Templist ==1 there is one product to Change
        #           c. If TempList >1 there are more than 1 products to Change and we take further steps to remove the Products
        chgProdName = p
        chgQuantity = q
        cartCount=len(self._cart)
        tempdict={}
        tempChgList=list()
        for i in range(cartCount):
            d1= self._cart[i]
            if d1["Name"] == chgProdName and d1["Type"]=='Clothing':
                tempdict={"Type":"Clothing","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"Size":d1["Size"],"Material":d1["Material"],"EAN":d1["EAN"]}
                tempChgList.append(tempdict)
            elif d1["Name"] == chgProdName and d1["Type"]=='Food':
                tempdict={"Type":"Food","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"ExpiryDate":d1["ExpiryDate"],"GlutenFree":d1["GlutenFree"],"SuitableforVegan":d1["SuitableforVegan"],"EAN":d1["EAN"]}
                tempChgList.append(tempdict)
            elif d1["Name"] == chgProdName and d1["Type"]=='Beverages':
                tempdict={"Type":"Clothing","Name":d1["Name"],"Brand":d1["Brand"],"Price":d1["Price"], "Quantity":d1["Quantity"],"Size":d1["BType"],"Material":d1["SuitableTemp"],"EAN":d1["EAN"]}
                tempChgList.append(tempdict)
        # There are no Products to Change
        if not tempChgList:
                print("***********Invalid Product. The Current Operation is cancelled .Please try again with correct Product Name***************")
                return self._cart
        
        # Has just 1 product to Change
        elif len(tempChgList) == 1:
            cartCount=len(self._cart)
            tempdict={}
            for i in range(cartCount):
                d1= self._cart[i]
                tempdict= tempChgList[0]
                if d1["Name"] == tempdict["Name"] and d1["Type"]=='Clothing':
                    tempdict["Quantity"]=chgQuantity
                    self._cart.pop(i)
                    self._cart.append(tempdict)
                    print("The Quantity of the Product",chgProdName, " has been changed in the cart")
                    return self._cart
                    break
                elif d1["Name"] == tempdict["Name"] and d1["Type"]=='Food':
                    tempdict["Quantity"]=chgQuantity
                    self._cart.pop(i)
                    self._cart.append(tempdict)
                    print("The Quantity of the Product",chgProdName, " has been changed in the cart")
                    return self._cart
                    break
                if d1["Name"] == tempdict["Name"] and d1["Type"]=='Beverages':
                    tempdict["Quantity"]=chgQuantity
                    self._cart.pop(i)
                    self._cart.append(tempdict)
                    print("The Quantity of the Product",chgProdName, " has been changed in the cart")
                    return self._cart
                    break
        # Has more than 1 Products to Change        
        elif len(tempChgList)>1:

            cartCount=len(tempChgList)
            tempdict={}
            
            print("Clothing Products \n")
            print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format("Sno","Type","EAN","Name","Brand","Price","Quantity","Size","Material"))
            for i in range(cartCount):
                d1= tempChgList[i]
                if d1["Type"]=='Clothing':
                    print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format(i,d1["Type"],str(d1["EAN"]),d1["Name"],d1["Brand"],str(d1["Price"]),str(d1["Quantity"]),d1["Size"],d1["Material"]))
            
            print("\n\n")
            print("______________________________________________________________________________________________________________________________________________________________")
            print("Food Products \n")
            print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format("Sno","Type","EAN","Name","Brand","Price","Quantity","ExpiryDate","GlutenFree","SuitableforVegan"))
            for i in range(cartCount):
                d1=tempChgList[i]
                if d1["Type"]=='Food':
                    print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format(i,d1["Type"],str(d1["EAN"]),d1["Name"],d1["Brand"],str(d1["Price"]),str(d1["Quantity"]),d1["ExpiryDate"],d1["GlutenFree"],d1["SuitableforVegan"]))
            print("______________________________________________________________________________________________________________________________________________________________")
            
            print("Beverages \n")
            print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format("Sno","Type","EAN","Name","Brand","Price","Quantity","BType","SuitableTemp"))
            for i in range(cartCount):
                d1= tempChgList[i]
                if d1["Type"]=='Clothing':
                    print("{:<3}|{:<15}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}|{:<20}".format(i,d1["Type"],str(d1["EAN"]),d1["Name"],d1["Brand"],str(d1["Price"]),str(d1["Quantity"]),d1["BType"],d1["SuitableTemp"]))
            
            
            print("There are "+str(len(tempChgList))+ "  products to remove. Please enter the Serial Number of which Product you should Remove: ")            
            print("Please enter the Product Type and EAN to Change")
            chgProdType = input("Product Type: ")
            if chgProdType.upper()=='C':
                print("The Current Operation is cancelled")
                return self._cart
            chgProdEAN = input("EAN: ")
            if  str(chgProdEAN).upper()=='C':
                print("The Current Operation is cancelled")
                return self._cart
            
            inpValidation=0
            cartCount=len(self._cart)
            for i in range(cartCount):
                d1=self._cart[i]
                if d1["Type"].upper()==chgProdType.upper() and d1["EAN"]==chgProdEAN:
                    d1["Quantity"]=chgQuantity
                    self._cart.pop(i)
                    self._cart.append(d1)
                    inpValidation+=1
            
            
            if inpValidation==0:
                print("Invalid Inputs Please try again with the correct options")
            
            return self._cart
            
         
def ShoppingOptions():
    return (input("Enter your Option:\n"+"[H] for help       "))
    
#Input validation for the Products that are going to be added to the mart
# We pass the attrbiute type and its value and validate the inputs
#  For exmaple , for EAN we pass 2 attribute 
#               1. the attribute type = EAN (13 Digit Number) 
#               2. the value of the EAN
#               3. Check if the EAN values are match i/p criteria and if there are exceptions we raise exception and request the user to enter the correct Input.
#               4. THe correct input is then returned for further processing
#               5. Of course, we have included the funtionality to cancel operation at any time why 'C' is pressed
def productInputValidation(attr,val,SL=list()):

        #Extract the EAN from the list
    SL=SL
    EANCheck=list()
    if SL:
        for i in range(len(SL)):
            d1= SL[i] 
            EANCheck.append(d1["EAN"])
    else:
        EANCheck.append('None')            
    if val.upper()=="C":
        return "C"
    if attr=="name":
        while attr=='name' and not val :
            print("Name Cannot be Empty!")
            val=input("Enter the name: ")
        return val
    

    if attr == "price (in £)":
        try:
            while ((float(val) and attr=="price (in £)" and float(val)<0) or (attr=="price (in £)" and not val )):
                print("Invalid Input. Please enter a Postive Integer Value")
                val=input("Enter the price (in £): ")
        except ValueError:
                if val.upper() == "C":
                    return "C"
                else: 
                    val = productInputValidation("price (in £)","-5")
                
        return val

    if attr == "quantity":
        try:
            while ((int(val) and attr=="quantity" and int(val)<0) or (attr=='quantity' and not val )):
                print("Invalid Input. Please enter a Postive Value without decimals")    
                val=input("Enter the quantity: ")
        except ValueError:
                
                if val.upper() == "C":
                    return "C"
                else: 
                    val = productInputValidation("quantity","-5")
        return val    

    if attr == "suitable temp":
        try:
            while ( float(val) and attr=="suitable temp" ):
                return val
        except ValueError:
            print("Invalid Input. Please enter an Integer Value")      
            val=input("Enter the suitable temp: ")
            if val.upper() == "C":
                return "C"
            else: 
                val = productInputValidation("suitable temp",val)
        return val 
    
    if attr =="EAN (13 Digit Number)":
        
        try:
            while (val and attr=="EAN (13 Digit Number)" and int(val)<0) or (attr=='EAN (13 Digit Number)' and not val) or (len(val)!=13) or (val in EANCheck):
                print("Invalid Input/Duplicate EAN (if you are trying to add more quantity please use the Change quantity option). Please enter a 13 digit Postive Integer Value")
                val=input("Enter the EAN: ")
        except ValueError:
                
                if val.upper() == "C":
                    return "C"
                else: 
                    val = productInputValidation("EAN (13 Digit Number)","-5",SL)
        return val
    
    
    if attr == "expirydate('YYYY-MM-DD')":
        
        date_format = "%Y-%m-%d"
        currdate=str(datetime.datetime.now())[0:10]
        try:
            if datetime.datetime.strptime(currdate,date_format) < datetime.datetime.strptime(str(val),date_format):               
                return val
            else:
                val=input("Enter the Correct Date Format 'YYYY-MM-DD': ")
                return productInputValidation("expirydate('YYYY-MM-DD')",val)
        except ValueError:
            if val.upper() == "C":
                return "C"
            else:
                val=input("Enter the Correct Date Format 'YYYY-MM-DD': ")
                val= productInputValidation("expirydate('YYYY-MM-DD')",val)
        return val         

    if attr == "material":
        try:
            while isinstance(float(val),float):                                
                print("Material name cannot be just numbers. Please enter a correct name")
                val=input("Enter the material: ")
        except ValueError:
                if val.upper() == "C":
                    return "C"
                else: 
                    return val
                                            
    if attr in ['glutenfree(Y/N)','suitable for vegans(Y/N)']:
        while (str(val).upper() != 'Y' or str(val).upper() != 'N'):
             if str(val).upper() == "C":
                 return "C"
             elif str(val).upper() == "Y":
                 return "Y"
             elif str(val).upper() == "N":
                 return "N"
             print("Invalid Input. Please enter the value 'Y' or 'N'")
             val=input("Enter the "+attr+": ")
    return val    
    
    
    if attr not in ["name","price (in £)","quantity","EAN (13 Digit Number)","glutenfree(Y/N)","suitable for vegans(Y/N)","material"]:
        return val

#This is a function for the Cart Addition to get the inputs from the user and validate it
#It contains
#   a. Uses a loop to get values from the user into the 
#                ProdcutTypeCLothing List for 'Clothing' Type
#               ProductTypeFood list for 'Food' Type
#       This method reduces many lines of code rather than using multiple input statements
#Once validated it will be returned for cart addition.
def productDetails(ShoppingList=list()):
    productTypeClothing=['name','brand','price (in £)','quantity','size','material','EAN (13 Digit Number)']
    productTypeFood=['name','brand','price (in £)','quantity',"expirydate('YYYY-MM-DD')",'glutenfree(Y/N)','suitable for vegans(Y/N)','EAN (13 Digit Number)']
    productTypeBeverages=['name','brand','price (in £)','quantity','beveragetype','suitable temp','EAN (13 Digit Number)']
    SL=ShoppingList        
    print("\nAdding a new Product:")
    productType=input("Insert its type(Food/Clothing/Beverages):")
    
    if productType.upper() == "CLOTHING":
        for i in range(len(productTypeClothing)):
          inpValid = input("Enter the "+productTypeClothing[i]+": ")
          productTypeClothing[i] = productInputValidation(productTypeClothing[i],inpValid,SL)
          if productTypeClothing[i] == "C":
              return ("C")
        return ("Clothing",productTypeClothing[0],productTypeClothing[1],float(productTypeClothing[2]),int(productTypeClothing[3]),productTypeClothing[4],productTypeClothing[5],productTypeClothing[6])
        
    elif productType.upper() == "FOOD":
        for i in range(len(productTypeFood)):
             inpValid = input("Enter the "+productTypeFood[i]+": ")
             productTypeFood[i] = productInputValidation(productTypeFood[i],inpValid,SL)
             if productTypeFood[i] == "C":
              return ("C")
        return ("Food",productTypeFood[0],productTypeFood[1],float(productTypeFood[2]),int(productTypeFood[3]),productTypeFood[4],productTypeFood[5],productTypeFood[6],productTypeFood[7])
    
    elif productType.upper() == "BEVERAGES":
        for i in range(len(productTypeClothing)):
          inpValid = input("Enter the "+productTypeBeverages[i]+": ")
          productTypeBeverages[i] = productInputValidation(productTypeBeverages[i],inpValid,SL)
          if productTypeClothing[i] == "C":
              return ("C")
        return ("Beverages",productTypeBeverages[0],productTypeBeverages[1],float(productTypeBeverages[2]),int(productTypeBeverages[3]),productTypeBeverages[4],productTypeBeverages[5],productTypeBeverages[6])
        

#C is used a univeral value here to cancel the operation

    elif productType.upper() == "C":
        return ("C")
    else:
        print("Invalid Option, Please select from the below Options:\n  Clothing \n Food \n Beverages")
        return("Invalid")

        
#Main Function for Exceution        
def main():
    #Initialising the Parameters
    #a. ShoppingOptions set to default value, so that it goes to the while loop
    #b. Initialising an instance of the Shopping car class
    #c. Creating a dummpy list of instance so that it can be appened later
    shopOptions=""
    cart=ShoppingCart()
    
    #Storing the Shopping list here to validate the Inputs and quick generation of the JSON
    ShoppingList =list()
    
    # STarting Welcome Page
    print("\n-----------Welcome to the Shopping Cart--------------")
    print("---------Please select the options available below----------")
    print("[A] - Add a new Product to the cart")
    print("[R] - Remove a Product fromt the cart")
    print("[S] - Print the summary of the cart")
    print("[Q] - Change the quantity of a product")
    print("[E] - Export a JSON version of the cart")
    print("[C] - Cancel the Current Operation")
    print("[T] - Terminate the program")
    print("[H] - List of supported Commands")
    
    #PRogram Continues until it T is encountered
    while shopOptions !='T':
        shopOptions= ShoppingOptions().upper()
        
        if shopOptions == 'A':
            
            pDetails=["Start Adding"]
            while pDetails[0] not in ['Clothing','Food','Beverages','C']:
                pDetails= productDetails(ShoppingList)
                if pDetails[0]=='Clothing':                
                    cProd=Clothing(pDetails[0],pDetails[1],pDetails[3],pDetails[7],pDetails[2],pDetails[4],pDetails[5],pDetails[6])                        
                    ShoppingList=cart.addProduct(cProd)
                    print("The item is added to the cart\n")
                    print("Number of Product/s in the Cart: ",len(ShoppingList))
                elif pDetails[0]=='Food':
                    fProd=Food(pDetails[0],pDetails[1],pDetails[3],pDetails[8],pDetails[2],pDetails[4],pDetails[5],pDetails[6],pDetails[7])
                    ShoppingList=cart.addProduct(fProd)
                    print("The item is added to the cart\n")
                    print("Number of item/s in the Cart: ",len(ShoppingList))
                if pDetails[0]=='Beverages':                
                    cProd=Beverages(pDetails[0],pDetails[1],pDetails[3],pDetails[7],pDetails[2],pDetails[4],pDetails[5],pDetails[6])                        
                    ShoppingList=cart.addProduct(cProd)
                    print("The item is added to the cart\n")
                    print("Number of Product/s in the Cart: ",len(ShoppingList))
                elif pDetails[0]=='C':
                    print("\n**************The Current Operation is Cancelled*******************")
                    break            
            
        elif shopOptions == 'R':
            print("Remove a Product")
            
            if not ShoppingList:
                print("There are no items in the Cart.\n Please enter the Products in the cart using 'A' option")    
            else:
                pDetailsRem= input("Enter the Product Name to be removed: ")
                ShoppingList = cart.removeProduct(pDetailsRem)
                print("No of item/s in the cart: ",len(ShoppingList))

        elif shopOptions == 'S':
            cart.showSummary()
            
            
        elif shopOptions == 'Q':
            print("Change the quantity of the Product")
            
            if not ShoppingList:
                print("There are no items in the Cart.\n Please enter the Products in the cart using 'A' option")    
            else:
                pDetailsChang= input("Enter the Product Name to be changed: ")
                pDetailsQuantity=input("Enter the quantity to be changed:")
                
                ShoppingList = cart.changeProductQuantity(pDetailsChang,pDetailsQuantity)
                print("No of item/s in the cart: ",len(ShoppingList))

# A simple function to dump the output of the cart into JSON  and print it                     
        elif shopOptions == 'E':            
            jsonPrint = json.dumps(ShoppingList)
            print("JSON version\n")
            print(jsonPrint)
       
#The Operation "C" cancels the current operation           
        elif shopOptions == 'C':
            
            print("\n**************The Current Operation is Cancelled*******************")
            pass
        
#Option to show the help menu here       
        elif shopOptions == 'H':
            print("\n-----------Help Options--------------")
            print("---------Commands Description----------")
            print("[A] - Add a new Product to the cart")
            print("[R] - Remove a Product fromt the cart")
            print("[S] - Print the summary of the cart")
            print("[Q] - Change the quantity of a product")
            print("[E] - Export a JSON version of the cart")
            print("[C] - Cancel the Current Operation")
            print("[T] - Terminate the program")
            print("[H] - List of supported Commands")            
            pass
#Operation to terminate the Program           
        elif shopOptions == 'T':
            print("--------The Program Ended------------")
            break
        else:
            print("\n\n**********Invalid Option Please Select again*********\n")

#The Prgram starts           
main()